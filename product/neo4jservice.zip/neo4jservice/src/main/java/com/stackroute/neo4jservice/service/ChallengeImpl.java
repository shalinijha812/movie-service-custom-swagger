package com.stackroute.neo4jservice.service;

import com.stackroute.neo4jservice.domain.nodes.Challenge;

import java.util.List;

public class ChallengeImpl implements ChallengeService {
    @Override
    public Challenge saveChallenge(Challenge challenge) {
        return null;
    }

    @Override
    public String deleteChallenge(String id) {
        return null;
    }

    @Override
    public List<Challenge> getAllChallenge() {
        return null;
    }

    @Override
    public List<Challenge> getSameLevelChallenge() {
        return null;
    }
}
