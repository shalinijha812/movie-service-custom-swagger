package com.stackroute.neo4jservice.domain.relation;

import com.stackroute.neo4jservice.domain.nodes.Concept;
import com.stackroute.neo4jservice.domain.nodes.Language;
import com.stackroute.neo4jservice.domain.nodes.Source;
import org.neo4j.ogm.annotation.EndNode;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.RelationshipEntity;
import org.neo4j.ogm.annotation.StartNode;

@RelationshipEntity(type = "isPartOf")
public class PartOfRelation{
    @Id
    private String id;

    @StartNode
    Language language;

    @EndNode
    Concept concept;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


}