package com.stackroute.neo4jservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Neo4jserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Neo4jserviceApplication.class, args);
	}
}
