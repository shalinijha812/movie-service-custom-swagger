package com.stackroute.neo4jservice.domain.relation;

import com.stackroute.neo4jservice.domain.nodes.Challenge;
import com.stackroute.neo4jservice.domain.nodes.User;
import com.sun.xml.internal.xsom.impl.scd.Iterators;
import org.neo4j.ogm.annotation.*;

import java.util.List;

@RelationshipEntity(type="isAttemptedBy")
public class Attempt {
    @Id
    private String id;
    @Property
    private String status;
    @Property
    private double score;
    public List<String> challengesAttempted;

    @StartNode
    Challenge challenge;

    @EndNode
    User user;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }
}
