package com.stackroute.neo4jservice.service;

import com.stackroute.neo4jservice.domain.nodes.User;

import java.util.List;

public interface Language {
    public Language saveLanguage(Language language);
    //public String deleteUser(String id);
    public List<Language> getAllLanguage();
}
