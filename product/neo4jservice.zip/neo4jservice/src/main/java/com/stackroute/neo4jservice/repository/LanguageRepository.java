package com.stackroute.neo4jservice.repository;

import com.stackroute.neo4jservice.domain.nodes.Language;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface LanguageRepository extends Neo4jRepository<Language,String> {
}
