package com.stackroute.neo4jservice.service;

import java.util.List;

public class ConceptServiceImpl implements ConceptService {
    @Override
    public ConceptService saveConcept(ConceptService conceptService) {
        return null;
    }

    @Override
    public List<ConceptService> getAllConcepts() {
        return null;
    }
}
