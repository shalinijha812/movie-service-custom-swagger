package com.stackroute.neo4jservice.service;

import java.util.List;

public interface ConceptService {
    public ConceptService saveConcept(ConceptService conceptService);
    //public String deleteUser(String id);
    public List<ConceptService> getAllConcepts();
}
